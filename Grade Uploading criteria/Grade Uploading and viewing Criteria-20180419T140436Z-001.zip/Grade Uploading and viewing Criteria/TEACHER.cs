﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Grade_Uploading_and_viewing_Criteria
{
    public class TEACHER
    {
        private string UserName;

        public string UserName1
        {
            get { return UserName; }
            set { UserName = value; }
        }
        private string Password;

        public string Password1
        {
            get { return Password; }
            set { Password = value; }
        }
    }
}