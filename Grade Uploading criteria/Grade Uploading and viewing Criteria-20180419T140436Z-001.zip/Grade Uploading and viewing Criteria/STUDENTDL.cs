﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections;


using System.ComponentModel;
using System.Data;
using System.Drawing;

namespace Grade_Uploading_and_viewing_Criteria
{
    public class STUDENTDL
    {
        public static ArrayList userName = new ArrayList();
        public static ArrayList password = new ArrayList();
    }
}